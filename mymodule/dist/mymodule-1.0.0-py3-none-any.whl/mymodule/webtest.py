import sys

def get_html():
    return "<span style='font-size: 18pt'>This HTML message comes from Python/" + sys.version + "</span>"

