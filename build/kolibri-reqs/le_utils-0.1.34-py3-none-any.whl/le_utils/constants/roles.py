# constants Kolibri roles
COACH = "coach"
LEARNER = "learner"


choices = (
    (COACH, "Coach"),
    (LEARNER, "Learner"),
)
