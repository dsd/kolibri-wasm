"""
The constants defined in the submodules of this module are intended
only to provide additional user metadata about content, and have no impact
on their functional roles in any Kolibri tools or platforms.
"""
