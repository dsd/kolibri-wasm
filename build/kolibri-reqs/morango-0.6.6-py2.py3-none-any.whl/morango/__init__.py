from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals

default_app_config = "morango.apps.MorangoConfig"
__version__ = "0.6.6"
